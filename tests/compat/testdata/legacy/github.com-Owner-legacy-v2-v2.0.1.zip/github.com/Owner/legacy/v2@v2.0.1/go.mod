module github.com/Owner/legacy/v2

go 1.20
